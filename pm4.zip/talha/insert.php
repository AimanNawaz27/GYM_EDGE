<?php
    if(isset($_POST['submit'])) {

    $fn = $_POST['first_name'];
    $ln = $_POST['last_name'];
    $em = $_POST['email'];
    $ps = $_POST['password'];
    $city = $_POST['city'];
    $phone = $_POST['phone'];
    $add = $_POST['address'];
    include  'db.php';
    $q="Insert into user (first_name,last_name,email,password,city,phone,address) VALUES('$fn','$ln','$em','$ps','$city','$phone','$add')";
        if($conn->query($q)==True){
        echo
        "<p style='background-color:#5eb762;width:25%;height:3%;margin-left:70%;margin-top:2%;text-align:center;color:white'><b>Successfuly Data Added </b></p>";
    }
        else{
        echo "<p style='background-color:#ff4242;width:25%;height:3%;margin-left:70%;margin-top:2%;text-align:center;color:white'><b>OOPS! Try Again</b></p>";
        echo "Error: " . $q . "<br>" . $conn->error;
    }
}
?>


