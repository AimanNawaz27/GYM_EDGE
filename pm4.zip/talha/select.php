<?php

	if(isset($_POST['submit'])) {
	
		$u=$_POST['first_name'];
		$p=$_POST['password'];
		include 'db.php';

		$q="Select * From user where first_name='$u' and password='$p' ";
			$result= $conn->query($q);
			if($result->num_rows > 0){
				$row=$result->fetch_assoc();
				session_start();
				$_SESSION['first_name']=$row['first_name'];
				$_SESSION['password']=$row['password'];
							
				if($u=='admin'){
					$_SESSION['admin']=$row['first_name'];
					$_SESSION['admin']=$row['password'];			
					header('location:admin/');
					
				}
				else{
					header('location:user/');
				}	
				
			}
	}		

