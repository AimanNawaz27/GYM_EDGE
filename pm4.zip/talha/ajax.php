<!-- Ajax Code -->
<script>
	$(document).ready(function() {
		$('#butsave').on('click', function() {
			$("#butsave").attr("disabled", "disabled");
			var name = $('#name').val();
			var gmail = $('#gmail').val();
			var message = $('#message').val();
			 // if(name!="" && gmail!="" && message!=""){
				$.ajax({
					url: "insert_feedback.php",
					type: "POST",
					data: {
						name: name,
						gmail: gmail,
						message: message			
					},
					cache: false,
					success: function(dataResult){
						var dataResult = JSON.parse(dataResult);
						if(dataResult.statusCode==200){
							$("#butsave").removeAttr("disabled");
							$('#fupForm').find('input:text').val('');
							$("#success").show();
							$('#success').html('FeedBack added successfully !'); 						
						}
						else if(dataResult.statusCode==201){
						   alert("Error occured !");
						}
						
					}
				});
			// }
			// else{
			// 	alert('Please fill all the field !');
			// }
		});
	});
</script>
<!-- End Ajax -->
