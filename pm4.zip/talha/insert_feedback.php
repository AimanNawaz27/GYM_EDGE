<?php
	include 'connection.php';
	$name=$_POST['name'];
	$gmail=$_POST['gmail'];
	$message=$_POST['message'];
	$sql = "INSERT INTO `user`( `name`, `gmail`, `message`) VALUES ('$name','$gmail','$message')";
	if (mysqli_query($conn, $sql)) {
		echo json_encode(array("statusCode"=>200));
	} 
	else {
		echo json_encode(array("statusCode"=>201));
	}
	mysqli_close($conn);
?>