<?php
$username = $_REQUEST['user'];
$password = $_REQUEST['pass'];

$username= stripcslashes($username);
$password= stripcslashes($password);

$username= mysqli_real_escape_string($username,'user');
$password= mysqli_real_escape_string($password,'pass');

echo "connecting db.";
$connection=mysqli_connect("localhost","root");
mysqli_select_db('login',$connection);
echo("database connected..");

$result=mysql_query("select * from users where username='$username' and password= '$password'") 
or die("failed to query database ". mysql_error());
$row=mysql_fetch_array($result);
if ($row['username']==$username && $row['password']==$password) {
	echo "Login Succeccfull \n ";
	echo "Welcome".$row['username'];
}
else{
	echo "sorry...Failed to login.";
}

?>