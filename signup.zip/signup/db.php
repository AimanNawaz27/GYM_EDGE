﻿<?php
$host= "localhost";
$user="root";
$pass= "";
$db= "gymedge";

$conn=new mysqli($host, $user, $pass, $db );
?>
