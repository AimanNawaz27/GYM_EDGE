<?php
include 'db.php';
$id=$_POST['id'];
$user=$_POST['username'];
$pass=$_POST['password'];

$query="Insert into 'users'('id','username','password') values($id,$username,$password)";
$result1=mysqli_query($connection,$query);

?>


