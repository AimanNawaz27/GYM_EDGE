<?php

include 'db.php';
$username = $POST['user'];
$password = $POST['pass'];

// $username= stripcslashes($username);
// $password= stripcslashes($password);

// $username= mysqli_real_escape_string($username,'user');
// $password= mysqli_real_escape_string($password,'pass');

echo "connecting database.";
$connection=mysqli_connect('localhost','root');
mysqli_select_db('login',$connection);
echo("database connected..");

// $query="insert into users('username','password') values($username,$password)";
// $result1=mysqli_query($connection,$query);
// // $result=mysqli_query("select * from users where username='$username' and password= '$password'") 
// // or die("failed to query database ". mysql_error());
// $row=mysql_fetch_array($result1);
// if ($row['username']==$username && $row['password']==$password) {
	// echo "Login Succeccfull \n ";
	// echo "Welcome".$row['username'];
// }
// else{
	// echo "sorry...Failed to login.";
// }


$q="insert into users('user','pass') values($username,$password)";
			$result= $conn->query($q);
			if($result->num_rows > 0){
				$row=$result->fetch_assoc();
				session_start();
				$_SESSION['user']=$row['user'];
				$_SESSION['pass']=$row['pass'];
							
				if($username=='admin'){
					$_SESSION['admin']=$row['user'];
					$_SESSION['admin']=$row['pass'];
					echo "admin";
					
					header('location:signup.php');
					
				}
				else{
					header('location:login.php');
		
				}	
				
			}

?>