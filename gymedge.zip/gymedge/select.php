<?php
include 'db.php';

$result=mysql_query("select * from 'users' where username='$user' and password= '$pass'") 
or die("failed to query database ". mysql_error());
$row=mysql_fetch_array($result1);
if ($row['username']==$user && $row['password']==$pass) {
	echo "Login Succeccfull \n ";
	echo "Welcome".$row['username'];
}
else{
	echo "sorry...Failed to login.";
}
?>

